import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import bst.BinarySearchTree;
import bst.BinarySearchTreeImpl;
import org.junit.Test;

/**
 * Test the recursive union implementation of Binary search tree.
 */
public class TestBST {

  @Test
  public void testAdd() {
    BinarySearchTree<String> bst = new BinarySearchTreeImpl<>();
    bst.add("abc");
    bst.add("xyz");
    assertEquals(2, bst.size());
  }

  @Test
  public void testHeight(){
    BinarySearchTree<Integer> bst = new BinarySearchTreeImpl<>();
    bst.add(20);
    bst.add(8);
    bst.add(30);
    bst.add(28);
    bst.add(31);
    bst.add(29);
    bst.add(27);
    bst.add(10);
    bst.add(5);
    bst.add(23);
    bst.add(25);
    bst.add(21);
    assertEquals(6,bst.height());
  }

  @Test
  public void testPresent(){
    BinarySearchTree<Integer> bst = new BinarySearchTreeImpl<>();
    bst.add(76);
    bst.add(81);
    bst.add(56);
    bst.add(86);
    bst.add(44);
    bst.add(56);
    bst.add(37);
    bst.add(23);
    bst.add(47);
    bst.add(23);
    bst.add(25);
    bst.add(21);
    assertTrue(bst.present(86));
    assertFalse(bst.present(10));
  }

  @Test
  public void testMinimum(){
    BinarySearchTree<Integer> bst = new BinarySearchTreeImpl<>();
//    bst.add(76);
//    bst.add(81);
//    bst.add(56);
//    bst.add(86);
//    bst.add(23);
//    bst.add(25);
//    bst.add(45);
    assertEquals(null,
            bst.minimum());
  }

  @Test
  public void testPreOrder(){
    BinarySearchTree<Integer> bst = new BinarySearchTreeImpl<>();
    bst.add(20);
    bst.add(12);
    bst.add(30);
    bst.add(8);
    bst.add(16);
    bst.add(25);
    bst.add(32);
    assertEquals("[]",bst.preOrder());
  }

  @Test
  public void TestInOrder(){
    BinarySearchTree<Integer> bst = new BinarySearchTreeImpl<>();
    bst.add(20);
    bst.add(12);
    bst.add(30);
    bst.add(8);
    bst.add(16);
    bst.add(25);
    bst.add(32);
    assertEquals("[8 12 16 20 25 30 32]",bst.inOrder());
  }

  @Test
  public void TestPostOrder(){
    BinarySearchTree<Integer> bst = new BinarySearchTreeImpl<>();
    bst.add(20);
    bst.add(12);
    bst.add(30);
    bst.add(8);
    bst.add(16);
    bst.add(25);
    bst.add(32);
    assertEquals("[8 16 12 25 32 30 20]",bst.postOrder());
  }

}
