package questions;

/**
 * An abstract class which represent the common behavior of different types of questions.
 */
public abstract class AbstractQuestion implements Question {


  protected String text;

  @Override
  public abstract String answer(String answer);

  @Override
  public String getText() {
    return this.text;
  }

  @Override
  public abstract int compareTo(Question o);

  /**
   * compares an abstract question to Likert type.
   *
   * @param likert Likert question.
   * @return returns 1 0 or -1 depending on the result of the comparison.
   */
  protected int compareToLikert(Likert likert) {
    return 1;
  }


  /**
   * compares an abstract question to True/False type.
   *
   * @param trueFalse TrueFalse question.
   * @return returns 1 0 or -1 depending on the result of the comparison.
   */
  protected int compareToTrueFalse(TrueFalse trueFalse) {
    return -1;
  }


  /**
   * compares an abstract question to Multiple Choice type.
   *
   * @param multipleChoice MultipleChoice question instance.
   * @return returns 1 0 or -1 depending on the result of the comparison.
   */

  protected int compareToMultipleChoice(MultipleChoice multipleChoice) {
    return 1;
  }


  /**
   * compares an abstract question to Multiple Select type.
   *
   * @param multiSelect MultipleSelect question instance.
   * @return returns 1 0 or -1 depending on the result of the comparison.
   */
  protected int compareToMultipleSelect(MultipleSelect multiSelect) {
    return 1;
  }


  protected void testQuestionText(String text) {
    if (text == null) {
      throw new IllegalArgumentException("The Question cannot be null");
    }
    if (text.trim().length() == 0) {
      throw new IllegalArgumentException("The Question text cannot be empty");
    }
  }


}
