package tictactoe;

import java.io.IOException;
import java.util.Scanner;

/**
 * This starter files is for students to implement a console controller for the
 * TicTacToe MVC assignment.
 */
public class TicTacToeConsoleController implements TicTacToeController {

  private final Appendable out;
  private final Scanner scan;

  /**
   * Constructor for the controller.
   *
   * @param in  the source to read from
   * @param out the target to print to
   */
  public TicTacToeConsoleController(Readable in, Appendable out) {
    if (in == null || out == null) {
      throw new IllegalArgumentException("Readable and Appendable can't be null");
    }
    this.out = out;
    scan = new Scanner(in);
  }

  @Override
  public void playGame(TicTacToe m) {
    String inputMessage;
    String strInput;
    int[] xy = new int[2];
    int counter = 0;
    boolean quit;
    do {
      inputMessage = String.format("Enter a move for %s", m.getTurn().toString());
      quit = false;
      try {
        out.append(inputMessage);
        while (counter < 2) {
          try {
            strInput = scan.next();
            if (strInput.equalsIgnoreCase("q")) {
              quit = true;
              break;
            }

            xy[counter] = Integer.parseInt(strInput);
            counter++;
            /*
            strInput = scan.next();
            if (strInput.equalsIgnoreCase("q")) {
              quit = true;
              break;
            }
            col = Integer.parseInt(strInput);
            counter++;
            */

          } catch (NumberFormatException nfe) {
            String invalidInput = String.valueOf(xy[counter]);
            out.append("Not a valid number:").append(invalidInput).append("\n");
            counter = 0;
          }
        }
        if (!quit) {
          m.move(xy[0], xy[1]);
        }
      } catch (IOException ioe) {
        throw new IllegalStateException("Append failed", ioe);
      } catch (IllegalArgumentException iae) {
        try {
          out.append(iae.getMessage()).append("\n");
        } catch (IOException ioe1) {
          throw new IllegalStateException("Append failed", ioe1);
        }
      }
      if (quit) {
        try {
          out.append("Game quit! Ending game state:").append(m.toString()).append("\n");
          break;
        } catch (IOException ioe) {
          throw new IllegalStateException("Append failed", ioe);
        }
      }

    }
    while (!m.isGameOver());
    if (m.isGameOver()) {
      try {
        out.append(m.toString()).append("\n");
        out.append("Game is over!");
        Player winner = m.getWinner();
        if (winner != null) {
          out.append(String.format("%s wins\n", winner));
        } else {
          out.append("Tie game");
        }
      } catch (IOException ioe) {
        throw new IllegalStateException("Append failed", ioe);
      }
    }


  }

}
