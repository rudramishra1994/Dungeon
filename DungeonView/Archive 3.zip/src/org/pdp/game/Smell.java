package org.pdp.game;

/**
 * The Intensity of smell at a location based on monster proximity.
 */
public enum Smell {
  LIGHT,
  HEAVY,
  NOSMELL;

}
