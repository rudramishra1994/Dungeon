package org.pdp.controller;

/**
 * Actions allowed to the user.
 */
public enum PlayerAction {
  EXIT,PICK,MOVE,SHOOT
}
