package org.pdp.game;

/**
 * The weapons that will be available for use in the dungeon.
 */
public enum Weapon {
  ARROW,
}
