package org.pdp.controller;

/**
 * Items the player can pick.
 */
public enum PickOption {
  ARROW,
  TREASURE,
}
