package org.pdp.game;

enum Notation {
  T,
  S,
  G,
  P,
  M,
  C,
  V,
  A,

}
