package org.pdp.game;

/**
 * The different treasures present in the dungeon.
 */
public enum Treasures {
  DIAMOND,
  RUBY,
  SAPPHIRE
}
