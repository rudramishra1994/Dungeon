import static org.junit.Assert.assertEquals;

import java.math.BigInteger;
import lookandsay.LookAndSayIterator;
import lookandsay.RIterator;
import org.junit.Test;

public class LookAndSayTest {

  @Test
  public void simpleSeedTest() {
    RIterator<BigInteger> it = new LookAndSayIterator();
    BigInteger num1 = it.next();
    assertEquals(new BigInteger("11"), num1);
  }

  @Test
  public void testHasNext(){
    RIterator<BigInteger> it = new LookAndSayIterator(new BigInteger("111111111111111111111"));
    for(int i = 0;i<10;i++){
      System.out.println(it.next());
    }
  }

  @Test
  public void testHasPrev(){
    RIterator<BigInteger> it = new LookAndSayIterator(new BigInteger("1113211322211312113211")
      ,new BigInteger("999999999999999999999999999999"));

    for(int i = 0;i<15;i++){
      System.out.println(it.prev());
    }
  }

}
